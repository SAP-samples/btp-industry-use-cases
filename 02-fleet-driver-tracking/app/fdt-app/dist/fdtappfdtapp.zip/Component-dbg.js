sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("fdt.app.fdtapp.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);